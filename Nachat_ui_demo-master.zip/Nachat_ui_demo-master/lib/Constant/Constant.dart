String
    CHAT_SCREEN = '/MyChatScreen',
    ANIMATED_SPLASH = '/SplashScreen';

