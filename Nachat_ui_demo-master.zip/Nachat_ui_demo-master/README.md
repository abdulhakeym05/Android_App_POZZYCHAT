# NACHAT DEMO CHATING

A NACHAT app to showcase Chat UI .

# Demo
<img height="480px" src="https://github.com/flutter-devs/flutter_chat_ui_demo/blob/master/screens/demo.gif">



# Android Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_chat_ui_demo/blob/master/screens/android1.jpg"> <img height="480px" src="https://github.com/flutter-devs/flutter_chat_ui_demo/blob/master/screens/android2.jpg"> 


# iOS Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_chat_ui_demo/blob/master/screens/iphone1.jpg"> <img height="480px" src="https://github.com/flutter-devs/flutter_chat_ui_demo/blob/master/screens/iphone2.jpg">



## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
