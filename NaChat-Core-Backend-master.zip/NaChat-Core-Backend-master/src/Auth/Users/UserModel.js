const mongoose = require("mongoose");

// const userProfile = new mongoose.Schema(
//     {
//         url:{
//             type:String
//         }
//     }
// )

const userSchema = new mongoose.Schema({
  fullname: {
    type: String,
    required: true,
    unique: true,
    max: 255,
    min: 6,
  },
  username: {
    type: String,
    required: true,
    unique: true,
    max: 255,
    min: 6,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    max: 255,
    min: 6,
  },
  password: {
    type: String,
    required: true,
    max: 2048,
    min: 1024,
  },
  phoneNumber: {
    type: String,
  },
  country: {
    type: String,
  },

  date: {
    type: Date,
    default: Date.now,
  },
  deleted: {
    type: Boolean,
    default: false,
  },
  isLogin:{
  type:Boolean,
  default:false
  },
salt:String,
otpSecret:String
});

module.exports = mongoose.model("User", userSchema);
