const User = require("./UserModel");
const password = require("../../../utils/hashpassword");
const Crypto = require("crypto");
const speakeasy = require("speakeasy"); //Generate a secret key First.
const otpSecret = speakeasy.generateSecret({ length: 30 }); //using speakeasy generate one time token.
const salt = Crypto.randomBytes(256).toString("hex");
const Otp = require("../../../utils/otp");

module.exports = {
  register: async (req, res) => {
    const emailExist = await User.findOne({ email: req.body.email });
    if (emailExist) return res.status(400).send("Emain alreald exists");

    const hashPassword = await password.appHashedPassword(
      req.body.password,
      salt
    );

    const user = new User({
      fullname: req.body.fullname,
      username: req.body.username,
      email: req.body.email,
      password: hashPassword,
      country: req.body.country,
      phoneNumber: req.body.phoneNumber,
      salt: salt,
      otpSecret: otpSecret.base32,
    });

    try {
      const userSave = await user.save();
      //choose to return just id of the saved user
      res.send({ user: user._id });
    } catch (err) {
      res.status(404).send("kijacode kill it");
      console.log(err);
    }
  },
  login: async (req, res) => {
    let response = await password.comparePassword(
      req.body.password,
      req.body.email
    );

    User.findByIdAndUpdate(
      { _id: response.userId },
      { $set: { otpSecret: otpSecret.base32 } },
      (err, result) => {
        if (err) {
          console.log(err);
        } else {
          console.log(result);
        }
      }
    );

    res.header("nachat_token", response.token).send({
      nachat_token: response.token,
      _id: response.userId,
    });
  },

  otp: async (req, res) => {
    console.log(req.params.id);
    const user = await User.findOne({ _id: req.params.id });
    let valres = await Otp.userOtp(user, req.body.token);
    if (valres) {
      User.findByIdAndUpdate(
        { _id: user._id },
        { $set: { isLogin: true } },
        (err, result) => {
          if (err) {
            console.log(err);
          } else {
            console.log(result);
          }
        }
      );

      res.json({
        login: true,
      });
    } else {
      console.log("fails");
      res.json({
        login: false,
      });
    }
    console.log(valres);
  },
};
