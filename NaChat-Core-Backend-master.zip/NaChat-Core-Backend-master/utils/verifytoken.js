const jwt = require("jsonwebtoken");
const appTOKEN = require("../configurations/development");

module.exports = {
  auth: (req, res, next) => {
    const token = req.header("nachat_token");

    if (!token) return res.status(401).send("Acesss Denied");

    try {
      const verified = jwt.verify(token, appTOKEN.TOKEN);
      req.user = verified;
      next();
    } catch (err) {
      res.status(400).send("Invalid Token");
    }
  },
};
