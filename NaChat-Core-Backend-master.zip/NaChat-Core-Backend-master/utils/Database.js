const mongoose = require('mongoose');
const config = require("../configurations/development");

console.log('db is here');
var  db_connection = mongoose.connect(
	config.mongo_url,
	{ userNewUrlParser: true },
	() => console.log('connect to db')
).then( async () =>{
    await console.log("Database havebeing connected");
    }).catch( (err) =>{
       console.log("Unable to connect to MongoDb");
       console.log(err);
    });
    

module.exports = db_connection;