const Crypto = require("crypto");
// const salt = Crypto.randomBytes(256).toString("hex");
const jwt = require("jsonwebtoken");
const User = require("../src/Auth/Users/UserModel");
const app_token = require("../configurations/development");
const otpfun = require("./otp");



const appHashedPassword =async (password,salt) => {
  const hashedPwd =await Crypto.pbkdf2Sync(password ,salt, 1000, 512, "sha512");
  
  return hashedPwd.toString("hex");
};

const comparePassword = async (attemptPassword,userEmail) =>{
  
  const user= await User.findOne({ email: userEmail });
  if (!user) return console.log('Email or Password not exist');
    await otpfun.appOtp(user);
  let hashedEntered_password =await  appHashedPassword(attemptPassword,user.salt);

  if(user.password == hashedEntered_password)
  {
    console.log("in")
    const token = jwt.sign({_id:user.__id},app_token.TOKEN, {
      expiresIn: "7d" // it will be expired after 7 days
      //expiresIn: "20d" // it will be expired after 20 days
     //expiresIn: 120 // it will be expired after 120ms
});

    // "Stack",
return {
  token:token,
  userId:user._id
};



 }else{
  console.log(user.password);
  console.log("gap")
  console.log(hashedEntered_password)
 }
  
}

module.exports = {appHashedPassword,comparePassword};
