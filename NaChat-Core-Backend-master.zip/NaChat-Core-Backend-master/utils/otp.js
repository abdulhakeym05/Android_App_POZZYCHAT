const speakeasy = require("speakeasy");
const nodemailer = require("nodemailer");
const env = require("../configurations/development");
// const User = require("../src/Auth/Users/UserModel");
//Generate a secret key First.

var secret = speakeasy.generateSecret({ length: 30 });
console.log(secret.base32); //using speakeasy generate one time token.

const appOtp = async (user) => {
  // const user= await User.findOne({ email: userEmail });
  const token = speakeasy.totp({
    secret: user.otpSecret,

    encoding: "base32",
  });
  console.log(token);

  sendEmails("musicadevelop@gmail.com", token);
};

const userOtp = async (user, enteredtoken) => {
  var tokenValidates = await speakeasy.totp.verify({
    secret: user.otpSecret,

    encoding: "base32",

    token: enteredtoken,

    window: 6,
  });

  return tokenValidates;
};

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    type: "login",
    user: env.email,
    pass: env.password,
  },
});

const sendEmails = (email, token) => {
  var sen = "Sen";

  const mailOptions = {
    from: env.email,
    to: email,
    subject: "NaChat Security Code",
    text: "Hello there thanks for Using NaChat your NaChat token is " + token,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
};

module.exports = { appOtp, userOtp };
