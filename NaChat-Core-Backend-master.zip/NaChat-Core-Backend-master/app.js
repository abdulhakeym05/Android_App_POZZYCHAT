const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const morgan = require("morgan");
const cors = require("cors");
const authUser = require("./src/Auth/Users/UserRoute");
const { errorHandler } = require("error-express-handler");
const db = require("./utils/Database");

app.use(bodyParser.json());

app.use(express.json());
app.use(cors());
app.use(morgan("dev"));
db;
app.use("/users/v1", authUser);

app.use(errorHandler);

module.exports = app;
