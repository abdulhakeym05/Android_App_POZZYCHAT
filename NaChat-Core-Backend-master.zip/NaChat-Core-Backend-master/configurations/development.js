module.exports={
    TOKEN: "WFHCJKJLSJFLJKLJLJK",
    mongo_url:"mongodb+srv://nachat:WNXkpDJ6rIHKXEFF@cluster0-mjwxv.mongodb.net/test?retryWrites=true&w=majority",
    email: "kijadanford@gmail.com",
    password:"07071997seven",

    
}